import matplotlib.pyplot as plt
import numpy as np
from sklearn.model_selection import train_test_split

from perceptron import Perceptron

# todo:  1. importing data as numpy arrays.
x_data = np.loadtxt(fname="train-a1-449.txt",
                    dtype=float,
                    delimiter=" ",
                    usecols=np.arange(0, 1024))

y_data = np.loadtxt(fname="train-a1-449.txt",
                    dtype=str,
                    delimiter=" ",
                    usecols=1024)

# convert output data to 1, -1
# i.e: 'Y' = 1 and 'N' = -1
y_data = np.where(y_data == 'Y', 1, -1)
#
# todo: 2. normalize and separate data to training set and test set.
x_data = x_data/np.linalg.norm(x_data, axis=1, keepdims=True) # two norm of each row
X_train, X_test, y_train, y_test = train_test_split(x_data, y_data, test_size=0.2, random_state=7)

# todo; 3. apply perceptron algorithm
perceptron = Perceptron()

perceptron.algorithm(x_data, y_data)
perceptron.train_accuracy()
perceptron.test_accuracy(x_data, y_data)

with open('results_HW1.txt', "w") as f:
    f.write(" ".join(map(str, perceptron.weights)))

# todo: 4.calculate the margin parameter (min(Y*(w.x)) of train data
print(f"Margin parameter: {perceptron.margin}")

#############################################################################################
# # For toy data set
# # todo:  1. importing data as numpy arrays.
# x_data = np.loadtxt(fname='data.txt',
#                     delimiter=' ')
# print(x_data)
# norms = np.linalg.norm(x_data, axis=1, keepdims=True) # two norm of each row
# x_data = x_data/norms
# print(x_data)
#
# y_data = np.loadtxt(fname='label.txt')
#
# # todo; 3. apply perceptron algorithm
# perceptron = Perceptron()
#
# perceptron.algorithm(x_data, y_data)
# perceptron.train_accuracy()
#
# print(perceptron.weights)
# perceptron.test_accuracy(x_data, y_data)
# print(f"Margin parameter: {perceptron.margin}")
#
# # w2y + w1x +w0 = 0 => y = -(w1x + w0)/w2
# plt.Figure()
# x = x_data[:,0]
# y = x_data[:,1]
#
# w2 = perceptron.weights[0]
# w1 = perceptron.weights[1]
# w0 = perceptron.weights[2]
# # w2 = perceptron.norm_weights[0]
# # w1 = perceptron.norm_weights[1]
# # w0 = perceptron.norm_weights[2]
#
# plt.plot(x, y, 'd')
# plt.plot(x, -(w1*x + w0)/w2)
# plt.show()


# k = perceptron.weights/np.power(np.sum(np.power(perceptron.weights,2)),0.5)